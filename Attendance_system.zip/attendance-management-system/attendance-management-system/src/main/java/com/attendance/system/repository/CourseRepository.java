package com.attendance.system.repository;

import com.attendance.system.entity.Course;
import com.attendance.system.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByAssignedTeacher(User teacher);
    List<Course> findByAssignedTeacherId(Long teacherId);
}