package com.attendance.system.repository;

import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.attendance.system.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByTeacher(User teacher);
    List<Student> findByTeacherId(Long teacherId);
    List<Student> findByCourse(Course course);
    List<Student> findByCourseId(Long courseId);
}