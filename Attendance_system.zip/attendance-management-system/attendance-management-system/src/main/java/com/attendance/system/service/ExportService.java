package com.attendance.system.service;

import com.attendance.system.entity.Attendance;
import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.opencsv.CSVWriter;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ExportService {

    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private UserService userService;

    /**
     * Export attendance data to CSV format
     */
    public String exportToCSV(LocalDate startDate, LocalDate endDate) throws IOException {
        StringWriter stringWriter = new StringWriter();
        CSVWriter csvWriter = new CSVWriter(stringWriter);

        // Write CSV header
        String[] header = {
                "Date", "Student Name", "Student Email", "Course", "Teacher",
                "Status", "Marked By", "Remarks", "Created At"
        };
        csvWriter.writeNext(header);

        // Get attendance data
        List<Attendance> attendanceList = getAttendanceData(startDate, endDate);

        // Write data rows
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        for (Attendance attendance : attendanceList) {
            String[] row = {
                    attendance.getDate() != null ? attendance.getDate().format(dateFormatter) : "",
                    attendance.getStudent() != null ? attendance.getStudent().getName() : "",
                    (attendance.getStudent() != null && attendance.getStudent().getEmail() != null) ? attendance.getStudent().getEmail() : "",
                    (attendance.getStudent() != null && attendance.getStudent().getCourse() != null) ? attendance.getStudent().getCourse().getName() : "No Course",
                    (attendance.getStudent() != null && attendance.getStudent().getTeacher() != null) ? attendance.getStudent().getTeacher().getUsername() : "No Teacher",
                    attendance.getStatus() != null ? attendance.getStatus().toString() : "",
                    attendance.getMarkedBy() != null ? attendance.getMarkedBy().getUsername() : "",
                    attendance.getRemarks() != null ? attendance.getRemarks() : "",
                    attendance.getCreatedAt() != null ? attendance.getCreatedAt().format(dateTimeFormatter) : ""
            };
            csvWriter.writeNext(row);
        }

        csvWriter.close();
        return stringWriter.toString();
    }

    /**
     * Export attendance data to Excel format
     */
    public byte[] exportToExcel(LocalDate startDate, LocalDate endDate) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Attendance Report");

        // Create header style
        CellStyle headerStyle = workbook.createCellStyle();
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // Create data style
        CellStyle dataStyle = workbook.createCellStyle();
        dataStyle.setWrapText(true);

        // Create header row
        Row headerRow = sheet.createRow(0);
        String[] headers = {
                "Date", "Student Name", "Student Email", "Course", "Teacher",
                "Status", "Marked By", "Remarks", "Created At"
        };

        for (int i = 0; i < headers.length; i++) {
            org.apache.poi.ss.usermodel.Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        // Get attendance data
        List<Attendance> attendanceList = getAttendanceData(startDate, endDate);

        // Create data rows
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        int rowNum = 1;
        for (Attendance attendance : attendanceList) {
            Row row = sheet.createRow(rowNum++);

            // Create cells with null checks
            org.apache.poi.ss.usermodel.Cell cell0 = row.createCell(0);
            cell0.setCellValue(attendance.getDate() != null ? attendance.getDate().format(dateFormatter) : "");
            cell0.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell1 = row.createCell(1);
            cell1.setCellValue(attendance.getStudent() != null ? attendance.getStudent().getName() : "");
            cell1.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell2 = row.createCell(2);
            cell2.setCellValue((attendance.getStudent() != null && attendance.getStudent().getEmail() != null) ? attendance.getStudent().getEmail() : "");
            cell2.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell3 = row.createCell(3);
            cell3.setCellValue((attendance.getStudent() != null && attendance.getStudent().getCourse() != null) ? attendance.getStudent().getCourse().getName() : "No Course");
            cell3.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell4 = row.createCell(4);
            cell4.setCellValue((attendance.getStudent() != null && attendance.getStudent().getTeacher() != null) ? attendance.getStudent().getTeacher().getUsername() : "No Teacher");
            cell4.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell5 = row.createCell(5);
            cell5.setCellValue(attendance.getStatus() != null ? attendance.getStatus().toString() : "");
            cell5.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell6 = row.createCell(6);
            cell6.setCellValue(attendance.getMarkedBy() != null ? attendance.getMarkedBy().getUsername() : "");
            cell6.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell7 = row.createCell(7);
            cell7.setCellValue(attendance.getRemarks() != null ? attendance.getRemarks() : "");
            cell7.setCellStyle(dataStyle);

            org.apache.poi.ss.usermodel.Cell cell8 = row.createCell(8);
            cell8.setCellValue(attendance.getCreatedAt() != null ? attendance.getCreatedAt().format(dateTimeFormatter) : "");
            cell8.setCellStyle(dataStyle);
        }

        // Auto-size columns
        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Convert to byte array
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        return outputStream.toByteArray();
    }


    public byte[] exportToPDF(LocalDate startDate, LocalDate endDate) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc);

        try {
            // Add title
            Paragraph title = new Paragraph("Attendance Report")
                    .setFontSize(18)
                    .setBold()
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(title);

            // Add date range
            Paragraph dateRange = new Paragraph(
                    String.format("Period: %s to %s",
                            startDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                            endDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))))
                    .setFontSize(12)
                    .setTextAlignment(TextAlignment.CENTER);
            document.add(dateRange);

            // Add some space
            document.add(new Paragraph("\n"));

            // Create table
            Table table = new Table(UnitValue.createPercentArray(new float[]{10, 20, 20, 15, 15, 10, 10}));
            table.setWidth(UnitValue.createPercentValue(100));

            // Add table headers
            String[] headers = {"Date", "Student Name", "Course", "Teacher", "Status", "Marked By", "Remarks"};
            for (String header : headers) {
                com.itextpdf.layout.element.Cell cell = new com.itextpdf.layout.element.Cell().add(new Paragraph(header)).setBold();
                table.addHeaderCell(cell);
            }

            // Get attendance data
            List<Attendance> attendanceList = getAttendanceData(startDate, endDate);

            // Add data rows
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMM dd");

            for (Attendance attendance : attendanceList) {
                // Date
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        attendance.getDate() != null ? attendance.getDate().format(dateFormatter) : "")));

                // Student Name
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        attendance.getStudent() != null ? attendance.getStudent().getName() : "")));

                // Course
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        (attendance.getStudent() != null && attendance.getStudent().getCourse() != null) ?
                                attendance.getStudent().getCourse().getName() : "No Course")));

                // Teacher
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        (attendance.getStudent() != null && attendance.getStudent().getTeacher() != null) ?
                                attendance.getStudent().getTeacher().getUsername() : "No Teacher")));

                // Status
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        attendance.getStatus() != null ? attendance.getStatus().toString() : "")));

                // Marked By
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        attendance.getMarkedBy() != null ? attendance.getMarkedBy().getUsername() : "")));

                // Remarks
                table.addCell(new com.itextpdf.layout.element.Cell().add(new Paragraph(
                        attendance.getRemarks() != null ? attendance.getRemarks() : "")));
            }

            document.add(table);

            // Add footer
            document.add(new Paragraph("\n"));
            Paragraph footer = new Paragraph(
                    String.format("Generated on: %s", LocalDate.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))))
                    .setFontSize(10)
                    .setTextAlignment(TextAlignment.RIGHT);
            document.add(footer);

        } finally {
            document.close();
        }

        return outputStream.toByteArray();
    }


    private List<Attendance> getAttendanceData(LocalDate startDate, LocalDate endDate) {
        List<Attendance> allAttendance = attendanceService.getAllAttendance();

        return allAttendance.stream()
                .filter(attendance -> {
                    LocalDate attendanceDate = attendance.getDate();
                    return attendanceDate != null &&
                            !attendanceDate.isBefore(startDate) &&
                            !attendanceDate.isAfter(endDate);
                })
                .sorted((a1, a2) -> {
                    // Sort by date first, then by student name
                    if (a1.getDate() == null && a2.getDate() == null) return 0;
                    if (a1.getDate() == null) return 1;
                    if (a2.getDate() == null) return -1;

                    int dateComparison = a1.getDate().compareTo(a2.getDate());
                    if (dateComparison != 0) {
                        return dateComparison;
                    }

                    String name1 = (a1.getStudent() != null) ? a1.getStudent().getName() : "";
                    String name2 = (a2.getStudent() != null) ? a2.getStudent().getName() : "";
                    return name1.compareTo(name2);
                })
                .toList();
    }


    public ExportSummary getExportSummary(LocalDate startDate, LocalDate endDate) {
        List<Attendance> attendanceList = getAttendanceData(startDate, endDate);

        long totalRecords = attendanceList.size();
        long presentCount = attendanceList.stream()
                .filter(a -> a.getStatus() != null)
                .mapToLong(a -> a.getStatus() == Attendance.Status.PRESENT ? 1 : 0)
                .sum();
        long absentCount = attendanceList.stream()
                .filter(a -> a.getStatus() != null)
                .mapToLong(a -> a.getStatus() == Attendance.Status.ABSENT ? 1 : 0)
                .sum();
        long lateCount = attendanceList.stream()
                .filter(a -> a.getStatus() != null)
                .mapToLong(a -> a.getStatus() == Attendance.Status.LATE ? 1 : 0)
                .sum();
        long leaveCount = attendanceList.stream()
                .filter(a -> a.getStatus() != null)
                .mapToLong(a -> a.getStatus() == Attendance.Status.LEAVE ? 1 : 0)
                .sum();

        double attendanceRate = totalRecords > 0 ?
                (double) (presentCount + lateCount) / totalRecords * 100 : 0;

        return new ExportSummary(totalRecords, presentCount, absentCount,
                lateCount, leaveCount, attendanceRate);
    }


    public static class ExportSummary {
        private final long totalRecords;
        private final long presentCount;
        private final long absentCount;
        private final long lateCount;
        private final long leaveCount;
        private final double attendanceRate;

        public ExportSummary(long totalRecords, long presentCount, long absentCount,
                             long lateCount, long leaveCount, double attendanceRate) {
            this.totalRecords = totalRecords;
            this.presentCount = presentCount;
            this.absentCount = absentCount;
            this.lateCount = lateCount;
            this.leaveCount = leaveCount;
            this.attendanceRate = attendanceRate;
        }

        // Getters
        public long getTotalRecords() { return totalRecords; }
        public long getPresentCount() { return presentCount; }
        public long getAbsentCount() { return absentCount; }
        public long getLateCount() { return lateCount; }
        public long getLeaveCount() { return leaveCount; }
        public double getAttendanceRate() { return attendanceRate; }
    }
}