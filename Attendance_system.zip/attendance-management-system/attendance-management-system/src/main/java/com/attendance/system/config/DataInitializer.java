package com.attendance.system.config;

import com.attendance.system.entity.Course;
import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.attendance.system.repository.CourseRepository;
import com.attendance.system.repository.StudentRepository;
import com.attendance.system.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Create admin user if not exists
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(User.Role.ADMIN);
            userRepository.save(admin);
            System.out.println("Admin user created: username=admin, password=admin123");
        }

        // Create teacher user if not exists
        if (!userRepository.existsByUsername("teacher1")) {
            User teacher = new User();
            teacher.setUsername("teacher1");
            teacher.setPassword(passwordEncoder.encode("teacher123"));
            teacher.setRole(User.Role.TEACHER);
            User savedTeacher = userRepository.save(teacher);
            System.out.println("Teacher user created: username=teacher1, password=teacher123");

            // Create courses only if none exist
            if (courseRepository.count() == 0) {
                Course course1 = new Course();
                course1.setName("Computer Science");
                course1.setAssignedTeacher(savedTeacher);
                Course savedCourse1 = courseRepository.save(course1);

                Course course2 = new Course();
                course2.setName("Mathematics");
                course2.setAssignedTeacher(savedTeacher);
                Course savedCourse2 = courseRepository.save(course2);

                // Create students only if none exist
                if (studentRepository.count() == 0) {
                    Student student1 = new Student();
                    student1.setName("John Doe");
                    student1.setEmail("john@example.com");
                    student1.setCourse(savedCourse1);
                    student1.setTeacher(savedTeacher);
                    studentRepository.save(student1);

                    Student student2 = new Student();
                    student2.setName("Jane Smith");
                    student2.setEmail("jane@example.com");
                    student2.setCourse(savedCourse1);
                    student2.setTeacher(savedTeacher);
                    studentRepository.save(student2);

                    Student student3 = new Student();
                    student3.setName("Bob Johnson");
                    student3.setEmail("bob@example.com");
                    student3.setCourse(savedCourse2);
                    student3.setTeacher(savedTeacher);
                    studentRepository.save(student3);

                    Student student4 = new Student();
                    student4.setName("Alice Brown");
                    student4.setEmail("alice@example.com");
                    student4.setCourse(savedCourse2);
                    student4.setTeacher(savedTeacher);
                    studentRepository.save(student4);

                    System.out.println("Sample courses and students created");
                }
            }
        }
    }
}