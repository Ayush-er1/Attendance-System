package com.attendance.system.service;

import com.attendance.system.entity.User;
import com.attendance.system.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<User> getAllTeachers() {
        return userRepository.findByRole(User.Role.TEACHER);
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User saveUser(User user) {
        if (user.getId() == null) {
            // New user - always encode password
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        } else {
            // Existing user - handle password update carefully
            if (user.getPassword() != null && !user.getPassword().trim().isEmpty()) {
                // Only encode if it's not already a BCrypt hash
                if (!isBCryptHash(user.getPassword())) {
                    user.setPassword(passwordEncoder.encode(user.getPassword()));
                }
            } else {
                // No password provided - keep existing password
                Optional<User> existingUser = userRepository.findById(user.getId());
                if (existingUser.isPresent()) {
                    user.setPassword(existingUser.get().getPassword());
                }
            }
        }
        return userRepository.save(user);
    }

    public User createUser(String username, String password, User.Role role) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role);
        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public boolean existsByUsername(String username) {
        return userRepository.findByUsername(username).isPresent();
    }

    /**
     * Check if a password string is already a BCrypt hash
     * BCrypt hashes start with $2a$, $2b$, $2x$, or $2y$
     */
    private boolean isBCryptHash(String password) {
        return password != null &&
                (password.startsWith("$2a$") ||
                        password.startsWith("$2b$") ||
                        password.startsWith("$2x$") ||
                        password.startsWith("$2y$"));
    }


    public User updateUser(User user, String newPassword) {
        if (newPassword != null && !newPassword.trim().isEmpty()) {
            user.setPassword(passwordEncoder.encode(newPassword));
        }
        return userRepository.save(user);
    }
}