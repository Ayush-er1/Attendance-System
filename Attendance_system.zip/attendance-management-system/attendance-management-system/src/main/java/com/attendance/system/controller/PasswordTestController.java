package com.attendance.system.controller;

import com.attendance.system.entity.User;
import com.attendance.system.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;


@RestController
public class PasswordTestController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/test-password")
    public String testPassword(@RequestParam String username, @RequestParam String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);

        if (userOpt.isEmpty()) {
            return "User not found: " + username;
        }

        User user = userOpt.get();
        String storedHash = user.getPassword();
        boolean matches = passwordEncoder.matches(password, storedHash);

        return String.format(
                "Username: %s%n" +
                        "Stored hash: %s%n" +
                        "Hash length: %d%n" +
                        "Hash starts with $2a: %s%n" +
                        "Password matches: %s%n" +
                        "Role: %s",
                username,
                storedHash,
                storedHash.length(),
                storedHash.startsWith("$2a") || storedHash.startsWith("$2b"),
                matches,
                user.getRole()
        );
    }

    @GetMapping("/fix-passwords")
    public String fixPasswords() {
        StringBuilder result = new StringBuilder();

        // Fix admin password
        Optional<User> adminOpt = userRepository.findByUsername("admin");
        if (adminOpt.isPresent()) {
            User admin = adminOpt.get();
            String newHash = passwordEncoder.encode("admin123");
            admin.setPassword(newHash);
            userRepository.save(admin);
            result.append("Admin password fixed!\n");
        }

        // Fix teacher password
        Optional<User> teacherOpt = userRepository.findByUsername("teacher1");
        if (teacherOpt.isPresent()) {
            User teacher = teacherOpt.get();
            String newHash = passwordEncoder.encode("teacher123");
            teacher.setPassword(newHash);
            userRepository.save(teacher);
            result.append("Teacher password fixed!\n");
        }

        return result.toString();
    }
}