package com.attendance.system.service;

import com.attendance.system.entity.Course;
import com.attendance.system.entity.User;
import com.attendance.system.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Optional<Course> getCourseById(Long id) {
        return courseRepository.findById(id);
    }

    public List<Course> getCoursesByTeacher(User teacher) {
        return courseRepository.findByAssignedTeacher(teacher);
    }

    public List<Course> getCoursesByTeacherId(Long teacherId) {
        return courseRepository.findByAssignedTeacherId(teacherId);
    }

    public Course saveCourse(Course course) {
        return courseRepository.save(course);
    }

    public Course createCourse(String name, User assignedTeacher) {
        Course course = new Course();
        course.setName(name);
        course.setAssignedTeacher(assignedTeacher);
        return courseRepository.save(course);
    }

    public void deleteCourse(Long id) {
        courseRepository.deleteById(id);
    }
}
