package com.attendance.system.service;

import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.attendance.system.entity.Course;
import com.attendance.system.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public List<Student> getStudentsByTeacher(User teacher) {
        return studentRepository.findByTeacher(teacher);
    }

    public List<Student> getStudentsByTeacherId(Long teacherId) {
        return studentRepository.findByTeacherId(teacherId);
    }

    public List<Student> getStudentsByCourse(Course course) {
        return studentRepository.findByCourse(course);
    }

    public List<Student> getStudentsByCourseId(Long courseId) {
        return studentRepository.findByCourseId(courseId);
    }

    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    public Student createStudent(String name, String email, Course course, User teacher) {
        Student student = new Student();
        student.setName(name);
        student.setEmail(email);
        student.setCourse(course);
        student.setTeacher(teacher);
        return studentRepository.save(student);
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
}