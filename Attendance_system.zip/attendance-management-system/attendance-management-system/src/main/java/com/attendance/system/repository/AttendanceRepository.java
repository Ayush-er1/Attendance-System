package com.attendance.system.repository;

import com.attendance.system.entity.Attendance;
import com.attendance.system.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findByStudentAndDateBetween(Student student, LocalDate startDate, LocalDate endDate);
    List<Attendance> findByStudentId(Long studentId);
    List<Attendance> findByDate(LocalDate date);
    Optional<Attendance> findByStudentAndDate(Student student, LocalDate date);

    @Query("SELECT a FROM Attendance a WHERE a.student.teacher.id = :teacherId")
    List<Attendance> findByTeacherId(@Param("teacherId") Long teacherId);

    @Query("SELECT a FROM Attendance a WHERE a.student.teacher.id = :teacherId AND a.date = :date")
    List<Attendance> findByTeacherIdAndDate(@Param("teacherId") Long teacherId, @Param("date") LocalDate date);
}