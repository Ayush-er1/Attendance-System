package com.attendance.system.controller;

import com.attendance.system.entity.Attendance;
import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.attendance.system.service.AttendanceService;
import com.attendance.system.service.StudentService;
import com.attendance.system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private UserService userService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private AttendanceService attendanceService;

    private User getCurrentTeacher(Authentication authentication) {
        return userService.getUserByUsername(authentication.getName()).orElse(null);
    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        User teacher = getCurrentTeacher(authentication);
        if (teacher != null) {
            List<Student> students = studentService.getStudentsByTeacher(teacher);
            model.addAttribute("totalStudents", students.size());
            model.addAttribute("todayDate", LocalDate.now());
            model.addAttribute("teacher", teacher);
        }
        return "teacher/dashboard";
    }

    @GetMapping("/students")
    public String viewStudents(Authentication authentication, Model model) {
        User teacher = getCurrentTeacher(authentication);
        if (teacher != null) {
            List<Student> students = studentService.getStudentsByTeacher(teacher);

            //Get course
            List<String> courses = students.stream()
                    .map(student -> student.getCourse() != null ? student.getCourse().getName() : "No Course")
                    .distinct()
                    .collect(Collectors.toList());

            // Get today's attendance count
            LocalDate today = LocalDate.now();
            List<Attendance> todayAttendance = attendanceService.getAttendanceByTeacherAndDate(teacher.getId(), today);
            long todayAttendanceCount = todayAttendance.size();

            // Calculate attendance rate
            long totalStudents = students.size();
            String attendanceRate = totalStudents > 0 ?
                    Math.round((double) todayAttendanceCount / totalStudents * 100) + "%" : "0%";

            model.addAttribute("students", students);
            model.addAttribute("courses", courses);
            model.addAttribute("todayAttendanceCount", todayAttendanceCount);
            model.addAttribute("attendanceRate", attendanceRate);
        } else {
            // Handle case where teacher is null
            model.addAttribute("students", List.of());
            model.addAttribute("courses", List.of());
            model.addAttribute("todayAttendanceCount", 0);
            model.addAttribute("attendanceRate", "0%");
        }
        return "teacher/students";
    }

    @GetMapping("/attendance")
    public String markAttendance(Authentication authentication, Model model) {
        User teacher = getCurrentTeacher(authentication);
        if (teacher != null) {
            List<Student> students = studentService.getStudentsByTeacher(teacher);
            LocalDate today = LocalDate.now();

            // Get today's attendance
            List<Attendance> todayAttendance = attendanceService.getAttendanceByTeacherAndDate(teacher.getId(), today);

            model.addAttribute("students", students);
            model.addAttribute("todayAttendance", todayAttendance);
            model.addAttribute("today", today);
        } else {
            // Handle case where teacher is null
            model.addAttribute("students", List.of());
            model.addAttribute("todayAttendance", List.of());
            model.addAttribute("today", LocalDate.now());
        }
        return "teacher/attendance";
    }


    @PostMapping("/attendance/save")
    public String saveAttendance(@ModelAttribute AttendanceService.AttendanceRequest request,
                                 Authentication authentication,
                                 RedirectAttributes redirectAttributes) {
        try {
            User teacher = getCurrentTeacher(authentication);
            if (teacher == null) {
                redirectAttributes.addFlashAttribute("error", "Teacher not found!");
                return "redirect:/teacher/attendance";
            }


            request.setMarkedBy(teacher);

            // Set today's date if not already set
            if (request.getDate() == null) {
                request.setDate(LocalDate.now());
            }


            attendanceService.saveAttendance(request);

            redirectAttributes.addFlashAttribute("success", "Attendance saved successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to save attendance: " + e.getMessage());
            e.printStackTrace(); // For debugging
        }
        return "redirect:/teacher/attendance";
    }


    @PostMapping("/attendance/mark")
    public String markStudentAttendance(@RequestParam Long studentId,
                                        @RequestParam String status,
                                        Authentication authentication,
                                        RedirectAttributes redirectAttributes) {
        try {
            User teacher = getCurrentTeacher(authentication);
            if (teacher == null) {
                redirectAttributes.addFlashAttribute("error", "Teacher not found!");
                return "redirect:/teacher/attendance";
            }

            Optional<Student> student = studentService.getStudentById(studentId);

            if (student.isPresent()) {
                Attendance.Status attendanceStatus = Attendance.Status.valueOf(status.toUpperCase());
                attendanceService.markAttendance(student.get(), LocalDate.now(), attendanceStatus, teacher);
                redirectAttributes.addFlashAttribute("success", "Attendance marked successfully for " + student.get().getName() + "!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Student not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error marking attendance: " + e.getMessage());
            e.printStackTrace(); // For debugging
        }
        return "redirect:/teacher/attendance";
    }

    @GetMapping("/reports")
    public String viewReports(Authentication authentication, Model model) {
        User teacher = getCurrentTeacher(authentication);
        if (teacher != null) {
            List<Student> students = studentService.getStudentsByTeacher(teacher);
            List<Attendance> allAttendance = attendanceService.getAttendanceByTeacherId(teacher.getId());

            model.addAttribute("students", students);
            model.addAttribute("attendance", allAttendance);
        }
        return "teacher/reports";
    }
}