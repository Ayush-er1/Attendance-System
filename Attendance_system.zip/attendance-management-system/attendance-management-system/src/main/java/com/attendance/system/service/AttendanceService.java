package com.attendance.system.service;

import com.attendance.system.entity.Attendance;
import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.attendance.system.repository.AttendanceRepository;
import com.attendance.system.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private StudentRepository studentRepository;

    public List<Attendance> getAllAttendance() {
        return attendanceRepository.findAll();
    }

    public Optional<Attendance> getAttendanceById(Long id) {
        return attendanceRepository.findById(id);
    }

    public List<Attendance> getAttendanceByStudent(Student student) {
        return attendanceRepository.findByStudentId(student.getId());
    }

    public List<Attendance> getAttendanceByTeacherId(Long teacherId) {
        return attendanceRepository.findByTeacherId(teacherId);
    }

    public List<Attendance> getAttendanceByDate(LocalDate date) {
        return attendanceRepository.findByDate(date);
    }

    public List<Attendance> getAttendanceByTeacherAndDate(Long teacherId, LocalDate date) {
        return attendanceRepository.findByTeacherIdAndDate(teacherId, date);
    }

    public Optional<Attendance> getAttendanceByStudentAndDate(Student student, LocalDate date) {
        return attendanceRepository.findByStudentAndDate(student, date);
    }

    public Attendance saveAttendance(Attendance attendance) {
        return attendanceRepository.save(attendance);
    }

    public Attendance markAttendance(Student student, LocalDate date, Attendance.Status status, User markedBy) {
        Optional<Attendance> existingAttendance = getAttendanceByStudentAndDate(student, date);

        Attendance attendance;
        if (existingAttendance.isPresent()) {
            attendance = existingAttendance.get();
            attendance.setStatus(status);
            attendance.setMarkedBy(markedBy);
        } else {
            attendance = new Attendance();
            attendance.setStudent(student);
            attendance.setDate(date);
            attendance.setStatus(status);
            attendance.setMarkedBy(markedBy);
        }

        return attendanceRepository.save(attendance);
    }

    @Transactional
    public void saveAttendance(AttendanceRequest request) {
        LocalDate attendanceDate = request.getDate();
        User markedBy = request.getMarkedBy();

        for (AttendanceRequest.StudentAttendance studentAttendance : request.getStudents()) {
            if (studentAttendance.getStatus() != null && !studentAttendance.getStatus().isEmpty()) {
                // Find student by ID
                Optional<Student> studentOpt = studentRepository.findById(Long.valueOf(studentAttendance.getId()));

                if (studentOpt.isPresent()) {
                    Student student = studentOpt.get();
                    Attendance.Status status = Attendance.Status.valueOf(studentAttendance.getStatus());


                    Optional<Attendance> existingAttendance = getAttendanceByStudentAndDate(student, attendanceDate);

                    Attendance attendance;
                    if (existingAttendance.isPresent()) {
                        // Update existing attendance
                        attendance = existingAttendance.get();
                        attendance.setStatus(status);
                        attendance.setMarkedBy(markedBy);
                        attendance.setRemarks(studentAttendance.getRemarks());
                    } else {
                        // Create new attendance record
                        attendance = new Attendance();
                        attendance.setStudent(student);
                        attendance.setDate(attendanceDate);
                        attendance.setStatus(status);
                        attendance.setMarkedBy(markedBy);
                        attendance.setRemarks(studentAttendance.getRemarks());
                    }

                    attendanceRepository.save(attendance);
                }
            }
        }
    }

    public void deleteAttendance(Long id) {
        attendanceRepository.deleteById(id);
    }


    public static class AttendanceRequest {
        private Long courseId;
        private LocalDate date;
        private List<StudentAttendance> students;
        private User markedBy;

        // Constructors
        public AttendanceRequest() {}

        // Getters and Setters
        public Long getCourseId() {
            return courseId;
        }

        public void setCourseId(Long courseId) {
            this.courseId = courseId;
        }

        public LocalDate getDate() {
            return date;
        }

        public void setDate(LocalDate date) {
            this.date = date;
        }

        public List<StudentAttendance> getStudents() {
            return students;
        }

        public void setStudents(List<StudentAttendance> students) {
            this.students = students;
        }

        public User getMarkedBy() {
            return markedBy;
        }

        public void setMarkedBy(User markedBy) {
            this.markedBy = markedBy;
        }

        public static class StudentAttendance {
            private String id;
            private String status;
            private String remarks;

            // Constructors
            public StudentAttendance() {}

            // Getters and Setters
            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getStatus() {
                return status;
            }

            public void setStatus(String status) {
                this.status = status;
            }

            public String getRemarks() {
                return remarks;
            }

            public void setRemarks(String remarks) {
                this.remarks = remarks;
            }
        }
    }
}