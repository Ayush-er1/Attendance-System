package com.attendance.system.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class WorkingPasswordGenerator {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        // Generate REAL BCrypt hashes
        String adminHash = encoder.encode("admin123");
        String teacherHash = encoder.encode("teacher123");

        System.out.println("=== REAL BCRYPT HASHES ===");
        System.out.println("Admin (admin123): " + adminHash);
        System.out.println("Teacher (teacher123): " + teacherHash);

        System.out.println("\n=== SQL STATEMENTS ===");
        System.out.println("UPDATE users SET password = '" + adminHash + "' WHERE username = 'admin';");
        System.out.println("UPDATE users SET password = '" + teacherHash + "' WHERE username = 'teacher1';");

        // Verify they work
        System.out.println("\n=== VERIFICATION ===");
        System.out.println("Admin hash works: " + encoder.matches("admin123", adminHash));
        System.out.println("Teacher hash works: " + encoder.matches("teacher123", teacherHash));
    }
}