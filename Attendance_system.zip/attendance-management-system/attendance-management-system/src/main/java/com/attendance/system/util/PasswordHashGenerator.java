package com.attendance.system.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordHashGenerator {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        // Generate hash for admin123
        String adminPassword = "admin123";
        String adminHash = encoder.encode(adminPassword);
        System.out.println("Admin password hash: " + adminHash);

        // Generate hash for teacher123
        String teacherPassword = "teacher123";
        String teacherHash = encoder.encode(teacherPassword);
        System.out.println("Teacher password hash: " + teacherHash);

        // Verify the hashes work
        System.out.println("Admin hash matches: " + encoder.matches(adminPassword, adminHash));
        System.out.println("Teacher hash matches: " + encoder.matches(teacherPassword, teacherHash));
    }
}