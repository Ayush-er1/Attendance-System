package com.attendance.system.controller;

import com.attendance.system.entity.Course;
import com.attendance.system.entity.Student;
import com.attendance.system.entity.User;
import com.attendance.system.service.AttendanceService;
import com.attendance.system.service.CourseService;
import com.attendance.system.service.StudentService;
import com.attendance.system.service.UserService;
import com.attendance.system.service.ExportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private AttendanceService attendanceService;

    @Autowired
    private ExportService exportService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalTeachers", userService.getAllTeachers().size());
        model.addAttribute("totalStudents", studentService.getAllStudents().size());
        model.addAttribute("totalCourses", courseService.getAllCourses().size());
        return "admin/dashboard";
    }

    // Export
    @GetMapping("/export/csv")
    public ResponseEntity<String> exportCSV(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        try {
            String csvContent = exportService.exportToCSV(startDate, endDate);

            String filename = String.format("attendance_report_%s_to_%s.csv",
                    startDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);
            headers.setContentDispositionFormData("attachment", filename);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(csvContent);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error generating CSV: " + e.getMessage());
        }
    }

    @GetMapping("/export/excel")
    public ResponseEntity<byte[]> exportExcel(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        try {
            byte[] excelContent = exportService.exportToExcel(startDate, endDate);

            String filename = String.format("attendance_report_%s_to_%s.xlsx",
                    startDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", filename);
            headers.setContentLength(excelContent.length);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(excelContent);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("Error generating Excel: " + e.getMessage()).getBytes());
        }
    }

    @GetMapping("/export/pdf")
    public ResponseEntity<byte[]> exportPDF(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        try {
            byte[] pdfContent = exportService.exportToPDF(startDate, endDate);

            String filename = String.format("attendance_report_%s_to_%s.pdf",
                    startDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                    endDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", filename);
            headers.setContentLength(pdfContent.length);

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(pdfContent);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("Error generating PDF: " + e.getMessage()).getBytes());
        }
    }

    @GetMapping("/export/summary")
    @ResponseBody
    public ResponseEntity<ExportService.ExportSummary> getExportSummary(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        try {
            ExportService.ExportSummary summary = exportService.getExportSummary(startDate, endDate);
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Teacher Management
    @GetMapping("/teachers")
    public String manageTeachers(Model model) {
        model.addAttribute("teachers", userService.getAllTeachers());
        model.addAttribute("newTeacher", new User());
        return "admin/teachers";
    }

    @PostMapping("/teachers/add")
    public String addTeacher(@ModelAttribute("newTeacher") User teacher, RedirectAttributes redirectAttributes) {
        try {
            if (userService.existsByUsername(teacher.getUsername())) {
                redirectAttributes.addFlashAttribute("error", "Username already exists!");
                return "redirect:/admin/teachers";
            }

            // Validate password
            if (teacher.getPassword() == null || teacher.getPassword().trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Password is required!");
                return "redirect:/admin/teachers";
            }

            teacher.setRole(User.Role.TEACHER);
            userService.saveUser(teacher);
            redirectAttributes.addFlashAttribute("success", "Teacher added successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error adding teacher: " + e.getMessage());
        }
        return "redirect:/admin/teachers";
    }

    @GetMapping("/teachers/edit/{id}")
    public String editTeacher(@PathVariable Long id, Model model) {
        Optional<User> teacher = userService.getUserById(id);
        if (teacher.isPresent()) {
            User teacherEntity = teacher.get();
            // Clear the password field for security - don't show the hashed password
            teacherEntity.setPassword("");
            model.addAttribute("teacher", teacherEntity);
            return "admin/edit-teacher";
        }
        return "redirect:/admin/teachers";
    }

    @PostMapping("/teachers/update/{id}")
    public String updateTeacher(@PathVariable Long id,
                                @RequestParam("username") String username,
                                @RequestParam(value = "password", required = false) String password,
                                RedirectAttributes redirectAttributes) {

        System.out.println("=== DEBUG: updateTeacher called ===");
        System.out.println("Teacher ID: " + id);
        System.out.println("Username: " + username);
        System.out.println("Password provided: " + (password != null && !password.trim().isEmpty()));
        System.out.println("Password length: " + (password != null ? password.length() : 0));

        try {
            Optional<User> existingTeacherOpt = userService.getUserById(id);
            if (existingTeacherOpt.isPresent()) {
                User existingTeacher = existingTeacherOpt.get();
                System.out.println("Found existing teacher: " + existingTeacher.getUsername());

                // Update username
                existingTeacher.setUsername(username);


                if (password != null && !password.trim().isEmpty()) {
                    System.out.println("Updating password with new value");

                    userService.updateUser(existingTeacher, password);
                } else {
                    System.out.println("No password provided - keeping existing password");
                    // Save without changing password
                    userService.saveUser(existingTeacher);
                }

                redirectAttributes.addFlashAttribute("success", "Teacher updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Teacher not found!");
            }
        } catch (Exception e) {
            System.out.println("ERROR: " + e.getMessage());
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Error updating teacher: " + e.getMessage());
        }
        return "redirect:/admin/teachers";
    }

    @GetMapping("/teachers/delete/{id}")
    public String deleteTeacher(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Optional<User> teacher = userService.getUserById(id);
            if (teacher.isPresent()) {
                userService.deleteUser(id);
                redirectAttributes.addFlashAttribute("success", "Teacher deleted successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Teacher not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting teacher: " + e.getMessage());
        }
        return "redirect:/admin/teachers";
    }

    // Student Management
    @GetMapping("/students")
    public String manageStudents(Model model) {
        model.addAttribute("students", studentService.getAllStudents());
        model.addAttribute("courses", courseService.getAllCourses());
        model.addAttribute("teachers", userService.getAllTeachers());
        model.addAttribute("newStudent", new Student());
        return "admin/students";
    }

    @PostMapping("/students/add")
    public String addStudent(@ModelAttribute("newStudent") Student student, RedirectAttributes redirectAttributes) {
        try {
            studentService.saveStudent(student);
            redirectAttributes.addFlashAttribute("success", "Student added successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error adding student: " + e.getMessage());
        }
        return "redirect:/admin/students";
    }

    @GetMapping("/students/edit/{id}")
    public String editStudent(@PathVariable Long id, Model model) {
        Optional<Student> student = studentService.getStudentById(id);
        if (student.isPresent()) {
            model.addAttribute("student", student.get());
            model.addAttribute("courses", courseService.getAllCourses());
            model.addAttribute("teachers", userService.getAllTeachers());
            return "admin/edit-student";
        }
        return "redirect:/admin/students";
    }

    @PostMapping("/students/update/{id}")
    public String updateStudent(@PathVariable Long id,
                                @RequestParam("name") String name,
                                @RequestParam(value = "email", required = false) String email,
                                @RequestParam(value = "course.id", required = false) Long courseId,
                                @RequestParam(value = "teacher.id", required = false) Long teacherId,
                                RedirectAttributes redirectAttributes) {
        try {
            Optional<Student> studentOpt = studentService.getStudentById(id);
            if (studentOpt.isPresent()) {
                Student student = studentOpt.get();


                student.setName(name);
                student.setEmail(email);


                if (courseId != null && courseId > 0) {
                    Optional<Course> course = courseService.getCourseById(courseId);
                    student.setCourse(course.orElse(null));
                } else {
                    student.setCourse(null);
                }

                // Update teacher if provided
                if (teacherId != null && teacherId > 0) {
                    Optional<User> teacher = userService.getUserById(teacherId);
                    student.setTeacher(teacher.orElse(null));
                } else {
                    student.setTeacher(null);
                }

                studentService.saveStudent(student);
                redirectAttributes.addFlashAttribute("success", "Student updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Student not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error updating student: " + e.getMessage());
        }
        return "redirect:/admin/students";
    }

    @GetMapping("/students/delete/{id}")
    public String deleteStudent(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Optional<Student> student = studentService.getStudentById(id);
            if (student.isPresent()) {
                studentService.deleteStudent(id);
                redirectAttributes.addFlashAttribute("success", "Student deleted successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Student not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting student: " + e.getMessage());
        }
        return "redirect:/admin/students";
    }

    // Course Management
    @GetMapping("/courses")
    public String manageCourses(Model model) {
        System.out.println("=== DEBUG: manageCourses method called ===");

        try {
            List<Course> courses = courseService.getAllCourses();
            List<User> teachers = userService.getAllTeachers();

            System.out.println("DEBUG: Found " + courses.size() + " courses");
            System.out.println("DEBUG: Found " + teachers.size() + " teachers");

            model.addAttribute("courses", courses);
            model.addAttribute("teachers", teachers);
            model.addAttribute("newCourse", new Course());

            System.out.println("DEBUG: Returning template 'admin/courses'");
            return "admin/courses";

        } catch (Exception e) {
            System.out.println("DEBUG: Exception in manageCourses: " + e.getMessage());
            e.printStackTrace();
            model.addAttribute("error", "Error loading courses: " + e.getMessage());
            return "admin/courses";
        }
    }

    @PostMapping("/courses/add")
    public String addCourse(@RequestParam("name") String name,
                            @RequestParam(value = "assignedTeacherId", required = false) Long assignedTeacherId,
                            RedirectAttributes redirectAttributes) {
        try {
            Course course = new Course();
            course.setName(name);

            // assigned teacher
            if (assignedTeacherId != null && assignedTeacherId > 0) {
                Optional<User> teacher = userService.getUserById(assignedTeacherId);
                if (teacher.isPresent()) {
                    course.setAssignedTeacher(teacher.get());
                }
            }

            courseService.saveCourse(course);
            redirectAttributes.addFlashAttribute("success", "Course '" + course.getName() + "' added successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error adding course: " + e.getMessage());
        }
        return "redirect:/admin/courses";
    }

    @PostMapping("/courses/update")
    public String updateCourse(@RequestParam("id") Long id,
                               @RequestParam("name") String name,
                               @RequestParam(value = "assignedTeacherId", required = false) Long assignedTeacherId,
                               RedirectAttributes redirectAttributes) {
        try {
            Optional<Course> courseOpt = courseService.getCourseById(id);
            if (courseOpt.isPresent()) {
                Course course = courseOpt.get();
                course.setName(name);

                // Set assigned teacher
                if (assignedTeacherId != null && assignedTeacherId > 0) {
                    Optional<User> teacher = userService.getUserById(assignedTeacherId);
                    if (teacher.isPresent()) {
                        course.setAssignedTeacher(teacher.get());
                    } else {
                        course.setAssignedTeacher(null);
                    }
                } else {
                    course.setAssignedTeacher(null);
                }

                courseService.saveCourse(course);
                redirectAttributes.addFlashAttribute("success", "Course updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Course not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error updating course: " + e.getMessage());
        }
        return "redirect:/admin/courses";
    }

    @PostMapping("/courses/delete")
    public String deleteCourse(@RequestParam("id") Long id, RedirectAttributes redirectAttributes) {
        try {
            Optional<Course> courseOpt = courseService.getCourseById(id);
            if (courseOpt.isPresent()) {
                Course course = courseOpt.get();
                courseService.deleteCourse(id);
                redirectAttributes.addFlashAttribute("success", "Course '" + course.getName() + "' deleted successfully!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Course not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error deleting course: " + e.getMessage());
        }
        return "redirect:/admin/courses";
    }

    @GetMapping("/courses/edit/{id}")
    public String editCourse(@PathVariable Long id, Model model) {
        Optional<Course> course = courseService.getCourseById(id);
        if (course.isPresent()) {
            model.addAttribute("course", course.get());
            model.addAttribute("teachers", userService.getAllTeachers());
            return "admin/edit-course";
        }
        return "redirect:/admin/courses";
    }

    // Test
    @GetMapping("/test")
    @ResponseBody
    public String testEndpoint() {
        return "Admin controller is working! Current time: " + java.time.LocalDateTime.now();
    }

    @GetMapping("/courses-test")
    @ResponseBody
    public String testCoursesEndpoint() {
        try {
            List<Course> courses = courseService.getAllCourses();
            List<User> teachers = userService.getAllTeachers();
            return "Courses endpoint working! Found " + courses.size() + " courses and " + teachers.size() + " teachers";
        } catch (Exception e) {
            return "Error in courses endpoint: " + e.getMessage();
        }
    }
}